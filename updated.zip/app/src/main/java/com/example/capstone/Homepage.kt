package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Homepage : AppCompatActivity() {

    private lateinit var bookNowButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)


        // Initialize the Book Now button
        bookNowButton = findViewById(R.id.book_now_button)

        // Set click listener for the Book Now button
        bookNowButton.setOnClickListener {
            val intent = Intent(this, Customer_Service::class.java)
            startActivity(intent)
        }
    }
}