package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class truckingvendor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_truckingvendor)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Spinner setup
        val truckSelectionSpinner = findViewById<Spinner>(R.id.truck_selection)
        val truckList = listOf("Choose", "4 Wheels", "6 Wheels", "6 Wheels FWD", "10 Wheels")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, truckList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        truckSelectionSpinner.adapter = adapter

        // Button to navigate to heatmap
        val mapButton = findViewById<Button>(R.id.button2)
        mapButton.setOnClickListener {
            val intent = Intent(this, heatmap::class.java)
            startActivity(intent)
        }

        // Button to navigate back to Fleet
        val backButton = findViewById<Button>(R.id.button)
        backButton.setOnClickListener {
            val intent = Intent(this, Fleet::class.java)
            startActivity(intent)
        }
    }
}
